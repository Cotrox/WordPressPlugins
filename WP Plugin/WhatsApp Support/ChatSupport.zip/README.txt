=== ChatSupport ===
Contributors: Cotrox, GraficaRuleZ
Tags: Chat, Support, WhatsApp, Supporto, Contact
Donate link: https://www.paypal.com/paypalme/graficarulez
Version: 0.1
Requires at least: 6.0
Tested up to: 6.0
Requires PHP: 7.2
License: GPL v2 or Later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add a new and Fluent WhatsApp Support Button to your WordPress Website.

== Description ==
Add a new and Fluent WhatsApp Support Button to your WordPress Website.

== Installation ==
Find our Plugin on WordPress and just press the Install button to let WordPress install it for you on your Website. Then press 'Activate' to switch it on.

To let WhatsSupport redirect users to the right link just go on your Admin Dashboard > WASupport and put in Settings your Business Phone Number.

== Changelog ==
0.1 - Introduce the Plugin installation and configuration.

== Upgrade Notice ==
Upgrade the plugin to be always up to date.